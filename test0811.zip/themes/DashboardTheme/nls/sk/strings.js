define({
  "_themeLabel": "Motív Dashboard",
  "_layout_default": "Predvolené rozloženie",
  "_layout_right": "Rozloženie vpravo"
});