define({
  "_themeLabel": "Тема на таблото за управление",
  "_layout_default": "Оформление по подразбиране",
  "_layout_right": "Дясно оформление"
});