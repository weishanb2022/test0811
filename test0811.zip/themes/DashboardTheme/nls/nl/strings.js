define({
  "_themeLabel": "Dashboard-thema",
  "_layout_default": "Standaardlay-out",
  "_layout_right": "Juiste lay-out"
});