define({
  "_themeLabel": "Dashbord-tema",
  "_layout_default": "Standardoppsett",
  "_layout_right": "Høyre-oppsett"
});