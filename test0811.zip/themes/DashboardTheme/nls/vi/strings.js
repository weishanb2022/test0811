define({
  "_themeLabel": "Chủ đề của bảng điều khiển",
  "_layout_default": "Bố cục mặc định",
  "_layout_right": "Bố cụng bên phải"
});