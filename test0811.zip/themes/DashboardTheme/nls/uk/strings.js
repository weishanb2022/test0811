define({
  "_themeLabel": "Тема Dashboard",
  "_layout_default": "Компонування за замовчуванням",
  "_layout_right": "Компонування справа"
});