define({
  "_themeLabel": "Dashboard-tema",
  "_layout_default": "Standardlayout",
  "_layout_right": "Højre-layout"
});